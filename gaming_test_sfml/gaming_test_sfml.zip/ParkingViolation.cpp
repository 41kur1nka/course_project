#include "ParkingViolation.h"
#include <cmath>
ParkingViolation::ParkingViolation(const sf::Vector2f &pos, const sf::Texture& carTex, const sf::Texture& questionTex):
	mCar(carTex), mQuestion(questionTex)
{
	mCar.setPosition(pos);
	// �������� �?� ���� ���� �����
	mQuestion.setPosition(
		pos.x + (carTex.getSize().x - questionTex.getSize().x) / 2.f,
		pos.y - questionTex.getSize().y - 5.f
	);
}

void ParkingViolation::update(const sf::Vector2f& playerPos)
{
	if (mResolved) return; // ��� ������
	float dx = playerPos.x - mCar.getPosition().x;
	float dy = playerPos.y - mCar.getPosition().y;
	mPlayerNear = (std::sqrt(dx * dx + dy * dy) < mTriggerDist);
}


void ParkingViolation::render(sf::RenderTarget& target)
{
	if (mResolved) return;
	target.draw(mCar);
	if (mPlayerNear)
		target.draw(mQuestion);
}
