#pragma once
#include "Incident.h"
#include <SFML/Graphics.hpp>

class ParkingViolation: public Incident {
public:
	ParkingViolation(const sf::Vector2f &position, const sf::Texture& carTex, const sf::Texture& questionTex);
	void update(const sf::Vector2f& playerPos) override;
	void render(sf::RenderTarget& target) override;
	bool isPlayerInRange() const { return mPlayerNear; }
	bool isResolved() const override { return mResolved; }

	// �������� �� GameLogic ��� �������� ����-����
	void resolve() { mResolved = true; }

private:
	sf::Sprite mCar;
	sf::Sprite mQuestion;    // ���� �?�
	float      mTriggerDist = 50.f;
	bool       mPlayerNear = false;
	bool       mResolved = false;
};